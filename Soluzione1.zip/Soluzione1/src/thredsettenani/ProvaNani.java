/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thredsettenani;

/**
 *
 * @author Mirko Cicali
 */
public class ProvaNani {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Thread thr1 = new ContaNani("Mammolo");
        Thread thr2 = new ContaNani("Cucciolo");
        Thread thr3 = new ContaNani("Gongolo");
        Thread thr4 = new ContaNani("Eolo");
        Thread thr5 = new ContaNani("Dotto");
        Thread thr6 = new ContaNani("Pisolo");
        Thread thr7 = new ContaNani("Brontolo");
        //li fo partire 
        thr1.start();
        thr2.start();
        thr3.start();
        thr4.start();
        thr5.start();
        thr6.start();
        thr7.start();
    }
    
}
