/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thredsettenani;

/**
 *
 * @author Mirko Cicali
 */
public class ProvaNani {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Thread thr1= new Thread (new ContaNani(),"Mammolo");
        thr1.start();
        Thread thr2= new Thread (new ContaNani(),"Cucciolo");
        thr2.start();
        Thread thr3= new Thread (new ContaNani(),"Gongolo");
        thr3.start();
        Thread thr4= new Thread (new ContaNani(),"Eolo");
        thr4.start();
        Thread thr5= new Thread (new ContaNani(),"Dotto");
        thr5.start();
        Thread thr6= new Thread (new ContaNani(),"Pisolo");
        thr6.start();
        Thread thr7= new Thread (new ContaNani(),"Brontolo");
        thr7.start();
    }
    
}
